package com.boot.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boot.dto.AnnounceDTO;
import com.boot.service.AnnounceService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/announce")
public class AnnounceController {
	
	@Autowired
	private AnnounceService announceService;
	
	@GetMapping("/announce_write")
	public String showAnnounce_writeForm() {
		return "announce/announce_write";
	}
	

	 @PostMapping("/announce_write")
	    public String registerPet(AnnounceDTO announce, HttpSession session) {
	        String userId = (String) session.getAttribute("id");
	        if (userId == null) {
	            return "redirect:/login";
	        }

	        announceService.insertAnnounce(announce);

	        return "redirect:/announce";
	    }
	 
	 @GetMapping("/update/{id}")
	 public String showUpdateForm(@PathVariable int id, Model model) {
		 AnnounceDTO announce = (AnnounceDTO) announceService.getAnnounceById(id);
		 model.addAttribute("announce", announce);
		 return "announce/announce_update";
	 }
	 


}
