package com.boot.controller;

import java.sql.Timestamp;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.dto.AnnounceDTO;
import com.boot.dto.PetDTO;
import com.boot.service.AnnounceService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AnnounceController {
	
	@GetMapping("/announce")
	public String list(Model model) {
		
		return "announce/announce";
	}
	
	@Autowired
	private AnnounceService announceService;
	
	@GetMapping("/announce_write")
	public String showAnnounce_writeForm() {
	    return "announce/announce_write";
	}

	@PostMapping("/announce_write")
	public String registerPet(AnnounceDTO announce, HttpSession session) {
	    String userId = (String) session.getAttribute("id");
	    if (userId == null) {
	        return "redirect:/login";
	    }

	    announceService.insertAnnounce(announce);

	    return "redirect:/announce";
	}
	 
	 @GetMapping("/update/{id}")
	 public String showUpdateForm(@PathVariable int id, Model model) {
		 AnnounceDTO announce = (AnnounceDTO) announceService.getAnnounceById(id);
		 model.addAttribute("announce", announce);
		 return "announce/announce_update";
	 }
	  @PostMapping("/update")
	    public String updatePet(
	            @RequestParam("id") int id,
	            @RequestParam("title") String title,
	            @RequestParam("content") String content,
	            @RequestParam("create_at") Timestamp create_at
	    ) {
	        AnnounceDTO announce = new AnnounceDTO();
	        announce.setId(id);
	        announce.setTitle(title);
	        announce.setContent(content);
	        announce.setTimestamp(create_at);
	        
	        

	        announceService.updateAnnounce(announce);

	        return "redirect:/announce/announce_update/" + id;
	    }
	 
	 
	    @GetMapping("/detail/{id}")
	    public String viewAnnounce(@PathVariable int id, Model model) {
	        AnnounceDTO announce = (AnnounceDTO) announceService.getAnnounceById(id);
	        model.addAttribute("announce", announce);
	        return "announce/announce_detail"; 
	    }
	 


}
