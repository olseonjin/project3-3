package com.boot.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.dto.AnnounceDTO;
import com.boot.dto.Criteria;
import com.boot.dto.FaqsDTO;
import com.boot.dto.PageDTO;
import com.boot.service.FaqannService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class AnnounceController {

	@Autowired
	private FaqannService service; // 공지사항과 FAQ 관련 비즈니스 로직을 처리하는 서비스 빈 주입

	// 공지사항 목록 페이지 요청 처리
	@RequestMapping("/announce")
	public String announce(Criteria cri, Model model) {
		log.info("@# announce()"); // 로그 출력
		log.info("@# cri=>" + cri); // 현재 페이지, 게시물 수 등 페이징 정보 확인용 로그

		// 페이징 처리된 공지사항 리스트 조회
		ArrayList<AnnounceDTO> announceList = service.announcelistWithPaging(cri);

		// 전체 공지사항 수 조회 (페이징 계산용)
		int total = service.announcegetTotalCount(cri);
		log.info("@# total=>" + total); // 전체 글 수 로그로 출력

		// 모델에 리스트와 페이징 정보 담아서 뷰에 전달
		model.addAttribute("announceList", announceList);
		model.addAttribute("pageMaker", new PageDTO(total, cri));

		return "announce"; // announce.jsp 로 포워딩
	}

	// 공지사항 작성 폼 요청 처리
	@RequestMapping("/announce_write")
	public String announce_write(Model model) {
		log.info("@# announce_write"); // 로그 출력

		// 작성 폼에는 특별한 데이터 필요 없음
		return "announce_write"; // announce_write.jsp 로 포워딩
	}

	// 공지사항 작성 후 저장 처리
	@RequestMapping("/announce_write_ok")
	public String announce_write_ok(AnnounceDTO announceDTO) {
		log.info("@# announce_write_ok"); // 로그 출력

		// 작성된 공지사항 DB에 저장
		service.announce_write_ok(announceDTO);
		log.info("@# announce작성완료!"); // 로그 출력

		// 공지사항 목록으로 리다이렉트
		return "redirect:/announce";
	}

	// 공지사항 상세보기 페이지 요청 처리
	@RequestMapping("/announce_view")
	public String announce_view(@RequestParam HashMap<String, String> param, Model model) {
		log.info("@# announce_view"); // 로그 출력

		// 해당 ID 또는 조건에 맞는 공지사항 상세 정보 조회
		AnnounceDTO dto = service.announce_view(param);

		// 모델에 공지사항 데이터와 요청 파라미터(페이징 정보 등) 전달
		model.addAttribute("announce_view", dto);
		model.addAttribute("pageMaker", param);

		log.info("@# announce_view param => " + param); // 파라미터 로그로 확인

		return "announce_view"; // announce_view.jsp 로 포워딩
	}
}
