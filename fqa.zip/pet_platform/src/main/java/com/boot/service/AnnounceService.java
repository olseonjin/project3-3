package com.boot.service;

import java.util.List;

import com.boot.dto.AnnounceDTO;

public interface AnnounceService {
	void insertAnnounce(AnnounceDTO announce);
	List<AnnounceDTO> getAllAnnounce();
	void updateAnnounce(AnnounceDTO announce);
	void deleteAnnounce(int id);
	List<AnnounceDTO> getAnnounceById(int id);
}
