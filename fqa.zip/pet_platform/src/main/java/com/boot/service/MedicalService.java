package com.boot.service;

import java.util.List;

import com.boot.dto.MedicalDTO;

public interface MedicalService {
	List<MedicalDTO> getAllMedical();
	public MedicalDTO getMedicalById(Long id);
}
