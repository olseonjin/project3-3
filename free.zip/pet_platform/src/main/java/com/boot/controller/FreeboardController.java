package com.boot.controller;

public class FreeboardController {

}
