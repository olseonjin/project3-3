package com.boot.dao;

import java.util.List;

import com.boot.dto.CommentDTO;

public interface CommentDAO {
	void insertComment(CommentDTO comment);
	List<CommentDTO> getCommentsByBoardID(Long boardId);
	void deleteComment(Long id);
}
