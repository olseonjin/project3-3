package com.boot.service;

import java.util.List;

import com.boot.dto.FreeboardDTO;

public interface FreeboardService {
	void insertFreeboard(FreeboardDTO freeboard);
	List<FreeboardDTO> getAllFreeboardDTO();
	FreeboardDTO getFreeboardDTOById(Long id);
}
