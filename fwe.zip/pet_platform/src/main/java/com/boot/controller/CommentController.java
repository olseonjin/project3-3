package com.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.dto.CommentDTO;
import com.boot.service.CommentService;

@Controller
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/comment/write")
    public String writeComment(CommentDTO comment) {
        commentService.insertComment(comment);
        return "redirect:/freeboard_detail?id=";
    }

    @GetMapping("/comment/delete")
    public String deleteComment(@RequestParam("id") int id, @RequestParam("boardId") int boardId) {
        commentService.deleteComment(id);
        return "redirect:/freeboard_detail?id=" + boardId;
    }
}
