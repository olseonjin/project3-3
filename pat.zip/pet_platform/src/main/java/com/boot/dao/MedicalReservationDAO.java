package com.boot.dao;

import com.boot.dto.MedicalReservationDTO;

public interface MedicalReservationDAO {
    void insertMedicalReservation(MedicalReservationDTO reservation);
}