package com.boot.service;

import com.boot.dto.MedicalReservationDTO;

public interface MedicalReservationService {
    void insertMedicalReservation(MedicalReservationDTO reservation);
}